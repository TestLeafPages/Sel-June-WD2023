package threadLocal;

public class Encapsulation {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
	/* setter,getter 
	 * setter -it will set value for that variable
	 * getter- it will get value from the setter
	 * */
}
