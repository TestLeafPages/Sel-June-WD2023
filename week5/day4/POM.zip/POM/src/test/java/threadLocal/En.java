package threadLocal;

public class En {

	public static void main(String[] args) {
		
		Encapsulation e= new Encapsulation();
		e.setName("Test");
		System.out.println(e.getName());

	}

}
