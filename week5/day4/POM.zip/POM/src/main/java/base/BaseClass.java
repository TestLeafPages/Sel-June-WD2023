package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.IntergrationWithTC;


public class BaseClass extends AbstractTestNGCucumberTests {

//parallel
	public  ChromeDriver driver;
	
	public String filename;
	
	//for parallel exc -static keyword will not work
	//seq
	//public static ChromeDriver driver;

	@BeforeMethod
	public void preCondition() {
		driver  = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	
	
	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
	
	
	
	
	@DataProvider(name="getdata",indices= {1})
	public String[][] setdata() throws IOException{
		return IntergrationWithTC.rundata(filename); 
	}
}
