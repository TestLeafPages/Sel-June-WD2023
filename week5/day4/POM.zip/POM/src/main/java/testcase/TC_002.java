package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002 extends BaseClass{

	@BeforeTest
	public void set() {
		filename="CreateLead";
	}

	@Test(dataProvider = "getdata")
	public void CreateLead(String cName,String fName,String lName) {
		
		LoginPage lp= new LoginPage(driver);
		System.out.println(driver);
		lp.enterUserName("DemoCsr").enterPassword("crmsfa")
		.clickOnLogin().clickOnCrmsfa().clickOnLeads()
		.clickOnCreateLead().enterCName(cName).enterFName(fName).enterLName(lName)
		.clickCreateButton().viewPage();
	}
}
