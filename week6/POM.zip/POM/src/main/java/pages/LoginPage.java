
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{

	
	  public LoginPage(ChromeDriver driver) { this.driver=driver; }
	 
	
	
	@And ("Enter the username as (.*)$")
	public LoginPage enterUserName() {
		driver.findElement(By.id("username")).sendKeys(pro.getProperty("username"));

		//m1
		/*
		 * LoginPage lp=new LoginPage(); 
		 * return lp;
		 */
		
		//m2
		return this;
	}
	
	@And ("Enter the password as (.*)$")
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys(pro.getProperty("password"));

		return this;
	}
	
	@When ("Click on the loginbutton")
	public HomePage clickOnLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();

		//m1
		/*
		 * HomePage hp=new HomePage(); return hp;
		 */
		
		//m2
		return new HomePage(driver);
	}
	
}
