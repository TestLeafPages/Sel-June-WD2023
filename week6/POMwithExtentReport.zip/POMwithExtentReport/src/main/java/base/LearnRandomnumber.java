package base;

public class LearnRandomnumber {

	public static void main(String[] args) {

		int random =(int)(Math.random()*999999);
		System.out.println(random);
		
		double random1 = Math.random();
		System.out.println(random1);
		
		//996565.477377701
		//9965656-convert number into int
	}

}
