package exceptiom;

public class LearnFinal {

	//we use in the variable ,class,method
	
	public  void add() {
		//i cannot overridde final method to other class
	}
}
