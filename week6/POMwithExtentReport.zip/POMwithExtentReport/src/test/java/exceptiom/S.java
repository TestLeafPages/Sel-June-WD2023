package exceptiom;

public class S {

	//classname.methodname
			
	public static void main(String[] args) {
		
		//classname.variablename
		System.out.println(LearnStatic.companyName);
		
		LearnStatic.name("Dilip");
	}
}
